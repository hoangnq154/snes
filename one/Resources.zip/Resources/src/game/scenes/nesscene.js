/**
 * Created by HOANGNGUYEN on 8/4/2017.
 */

//var nesLayer = null;
var allFree = true;
var listROM = null;
var currentTab = 1;

var hideIcon = true;
var hideGame = true;

var tangCount = function()
{
    var hideCount = parseInt(sys.localStorage.getItem("hideCount") || "0");
    hideCount++;
    if(hideCount >= 100)
        hideCount = 100;
    sys.localStorage.setItem("hideCount", ""+hideCount);
}

var NESLayer = BaseLayer.extend({
    ctor: function (data) {
        this._super();

        this.data = data;

        var gui_path = "res/GUI/CCBI/HomeLayerP.ccbi";
        if(gameData.screenType == SCREEN_LANSCAPE)
            gui_path = "res/GUI/CCBI/HomeLayer.ccbi";

        this.initGUICCB("res/GUI/", gui_path );
    },
    customizeGUI: function () {

        // display
        this.btnList.lb = this.lbList;
        this.btnFavorite.lb = this.lbFavorite;
        this.btnRecent.lb= this.lbRecent;
        this.btnPurchased.lb = this.lbPurchased;
        this.btnAbout.lb = this.lbAbout;



        this.bg.setScaleY(cc.winSize.height / this.bg.getContentSize.height);


        this.addTouchEventForButton(this.btnList);
        this.addTouchEventForButton(this.btnFavorite);
        this.addTouchEventForButton(this.btnRecent);
        this.addTouchEventForButton(this.btnPurchased);
        this.addTouchEventForButton(this.btnAbout);
        this.addTouchEventForButton(this.btnContact,113);
        this.addTouchEventForButton(this.btnEmail,115);

        this.addTouchEventForButton(this.btnADS,114);
        this.addTouchEventForButton(this.btnMenu,116);



        this.nogame.setString("");


        var tableViewSize = this.rootLayer.getContentSize();
        tableViewSize.height += cc.winSize.height - designResolutionSize.height;

        this.infoROM = new InfoROMLayer();
        this.infoROM.setViewSize(tableViewSize);
        this.rootLayer.addChild(this.infoROM);

        this.infoROM.setPositionX(cc.winSize.width);

        var hideCount = parseInt(sys.localStorage.getItem("hideCount") || "0");
                    if(hideCount >= gameData.count_show_icon)
                    {
                        hideIcon = false;
                    }

        if(hideIcon)
            this.btnADS.setVisible(false);
        else
        {
            this.btnADS.setVisible(!gameData.isPremium);
        }

        if(listROM == null)
        {
            listROM = (gameData.emulatorType == EMULATOR_NES)?(new ListRomLayer(tableViewSize)):(new ListRomSNESLayer(tableViewSize));
            this.listROM = listROM;

            currentTab = -1;

            listROM.setVisible(true);
            listROM.setPosition(cc.p(0,0));
            this.rootLayer.addChild(this.listROM);

            this.setKeypadEnabled(true);
            this.listROM.infoROM = this.infoROM;
            this.infoROM.listROM = this.listROM;

            this.onButtonReleased(this.btnList,this.btnList.getTag(),true);

        }
        else
        {
            this.listROM = listROM;

            listROM.setVisible(true);
            listROM.setPosition(cc.p(0,0));
            this.rootLayer.addChild(this.listROM);

            this.setKeypadEnabled(true);
            this.listROM.infoROM = this.infoROM;
            this.infoROM.listROM = this.listROM;

            if(currentTab != NESLayer.BTN_ALL || (hideCount == gameData.count_show_icon))
            {
                currentTab = -1;

                this.onButtonReleased(this.btnList,this.btnList.getTag(),true);
                if(hideCount == gameData.count_show_icon)
                {
                    this.btnADS.setVisible(!gameData.isPremium);
                }
            }
        }

        this.listROM.stopAllActions();
        this.infoROM.stopAllActions();
        this.listROM.setPosition(cc.p(0, 0));
        this.infoROM.setVisible(false);


        this.addChild(new UpdateDialog(),10);

    },
    onEnter: function () {
        this._super();

    },
    onDialogUpdateResult: function (id) {
        if (!cc.isNative || cc.sys.os === cc.sys.OS_IOS)
            this.gameScene.gameDisplay.play();
        if (id == 0) // update
        {
            engine.AdmobHelper.openURL(gameData.urlUpdate);
        }
        else {

        }
    },

    backClicked: function () {
        if (!this.isVisible() || !this.getParent())
            return;
        var menu = this.getChildByTag(333)
        if(menu != null )
        {
            menu.quit();
            return;
        }

        if(this.infoROM.isVisible())
        {
            this.listROM.runAction(cc.sequence(cc.show(), cc.moveTo(.2, cc.p(0, 0))));
            this.infoROM.runAction(cc.sequence(cc.moveTo(.2, cc.p(cc.winSize.width, 0)), cc.hide()));
            return;
        }

        var hideCount = parseInt(sys.localStorage.getItem("hideCount") || "0");
        if(hideCount < 2)
        {
            this.pushDialogExit();
            return;
        }

        //DialogUpdateProVersion.showDialog(this);
        //return;
        var rate = sys.localStorage.getItem("rate");
        if (rate == null || rate == "")   // chua tung an no thanks
        {
            this.addChild(new RateDialog(this), 10);
        }
        else    // an no thanks roi`, bat exit
        {
            this.pushDialogExit();
        }
    },
    pushDialogExit: function () {
        var dialog = new Dialog(this);
        dialog.content.setString("Do you want to exit game?");
        this.addChild(dialog, 10);
    },
    onDialogResult: function(id)
    {
        if(id == 0)
        {
            director.end();
        }
    },

    resetColor: function()
    {
        this.btnList.lb.setColor(cc.WHITE);
        this.btnFavorite.lb.setColor(cc.WHITE);
        this.btnRecent.lb.setColor(cc.WHITE);
        this.btnPurchased.lb.setColor(cc.WHITE);
        this.btnAbout.lb.setColor(cc.WHITE);

        this.btnList.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/btn_list_noselect.png",cc.rect(0,0,240,240)),cc.CONTROL_STATE_NORMAL);
        this.btnFavorite.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/yeuthich_no_select.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
        this.btnRecent.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/recent_noselect.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
        this.btnPurchased.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/mygame_noselect.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
        this.btnAbout.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/about_noselect.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);


    },

    onPurchase: function(id,jdata)
    {
        var obj = JSON.parse(jdata);
        cc.log(jdata);
        if(obj.error == 0)
        {
            gameData.isPremium = true;
        }
        else
        {
            gameData.isPremium = false;
        }
        this.btnADS.setVisible(!gameData.isPremium);

    },

    checkHideGame:function()            // check hide cac game nes trong list game hay ko
    {
        var hideGameCheck = parseInt(sys.localStorage.getItem("hideGame") || "0");
        hideGame = (hideGameCheck == 0);
    },

    onButtonReleased: function (btn, id , direct) {
        if (!this.isVisible() || !btn.isVisible())
            return;
        if(id == 113)
        {
            //engine.PlatformWrapper.sendEmail("8bitstudio154@gmail.com","","");
            if (cc.isNative)
                engine.AdmobHelper.openURL(gameData.urlRate || ("market://details?id="+cc.isNative?engine.PlatformWrapper.getPackageName():""));
            sys.localStorage.setItem("rate","daannothanks");
        }
        else if(id == 115)
        {
            engine.PlatformWrapper.sendEmail("8bitstudio154@gmail.com","Request new game","");
        }
        else if(id == 114)
        {
            if(cc.isNative)
            {
                handlerAdd("purchase",this.onPurchase.bind(this));
                engine.PlatformWrapper.purchase("");
            }
        }
        else if(id == 116)
        {
            this.addChild(new MenuLayer(this),3,333);
        }

        if(id == 1 || id == 3 || id == 5 || id == 7 || id == 9)
        {
            if(currentTab == id)
                return;
            currentTab = id;
            this.resetColor();
            this.icon.setVisible(false);
            this.btnContact.setVisible(false);
            this.btnEmail.setVisible(false);

            this.nogame.setString("");

            if(direct)
            {
                this.listROM.setPosition(cc.p(0, 0));
                this.infoROM.setVisible(false);

            }
            else
            {
                this.listROM.runAction(cc.sequence(cc.show(), cc.moveTo(.2, cc.p(0, 0))));
                this.infoROM.runAction(cc.sequence(cc.moveTo(.2, cc.p(cc.winSize.width, 0)), cc.hide()));

            }

            switch (id) {
                case NESLayer.BTN_ALL:
                {
                    btn.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/btn_list_select.png",cc.rect(0,0,240,240)),cc.CONTROL_STATE_NORMAL);
                    btn.lb.setColor(cc.color(41,134,178));
                    this.checkHideGame();
                    if(hideGame)
                    {
                        this.nogame.setString("Please add game from Menu");
                        this.listROM.loadData([]);
                    }
                    else
                    {
                        var datas = [];
                        var hideCount = parseInt(sys.localStorage.getItem("hideCount") || "0");
                        if(hideIcon || hideCount < 2)
                        {
                            if(gameData.emulatorType == EMULATOR_NES)
                                datas = DataManager.getInstance().datas;
                            else if(gameData.emulatorType == EMULATOR_SNES)
                            {
                                datas = DataManager.getInstance().dataSNES;
                            }
                        }
                        else
                        {
                            if(gameData.emulatorType == EMULATOR_NES)
                                datas = DataManager.getInstance().promoDatas.concat(DataManager.getInstance().datas);
                            else if(gameData.emulatorType == EMULATOR_SNES)
                            {
                                datas = DataManager.getInstance().promoDatas.concat(DataManager.getInstance().dataSNES);
                            }
                        }
                        this.listROM.loadData(datas);

                    }


                    break;
                }
                case NESLayer.BTN_FAVORITE:
                {
                    btn.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/yeuthich_select.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
                    btn.lb.setColor(cc.color(41,134,178));
                    this.listROM.loadData(DataManager.getInstance().romFavorites);
                    if(DataManager.getInstance().romFavorites.length == 0)
                        this.nogame.setString("No game in Favorite list");

                    break;
                }
                case NESLayer.BTN_RECENT:
                {
                    btn.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/recent_select.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
                    btn.lb.setColor(cc.color(41,134,178));

                    this.listROM.loadData(DataManager.getInstance().romRecents);

                    if(DataManager.getInstance().romRecents.length == 0)
                        this.nogame.setString("No game in Recent list");
                    break;
                }
                case NESLayer.BTN_PURCHASED:
                {
                    btn.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/mygame_select.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
                    btn.lb.setColor(cc.color(41,134,178));
                    this.listROM.loadData([]);

                    if(gameData.isPremium)
                        this.nogame.setString("You are Premium User without ADS");
                    else
                         this.nogame.setString("You can upgrade Premium User without ADS");

                    break;
                }
                case NESLayer.BTN_ABOUT:
                {
                    btn.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/about_select.png",cc.rect(0,0,261,264)),cc.CONTROL_STATE_NORMAL);
                    btn.lb.setColor(cc.color(41,134,178));
                    this.listROM.loadData([]);

                    this.nogame.setString("");
                    this.btnContact.setVisible(true);
                    this.btnEmail.setVisible(true);
                    this.icon.setVisible(true);

                    break;
                }
            }
        }

    }

})

NESLayer.BTN_ALL = 1;
NESLayer.BTN_RECENT = 5;
NESLayer.BTN_FAVORITE = 3;
NESLayer.BTN_PURCHASED = 7;
NESLayer.BTN_ABOUT = 9;


var NESCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        this.layers = [];
        var poss = [cc.p(10, 0), cc.p(232, 0), cc.p(455, 0), cc.p(700, 0), cc.p(920, 0)];

        for (var i = 0; i < GAME_IN_ROW; i++) {
            var layer = new BaseLayer();
            layer.initGUICCB("res/GUI/", "res/GUI/CCBI/RomCell.ccbi");
            layer.status.setVisible(false);
            this.addChild(layer);
            layer.setPosition(poss[i]);
            layer.starss= [];
            for(var j=1;j<=8;j++)
            {
                layer.starss.push(layer.stars.getChildByTag(j));
            }
            if(cc.isNative)
            {
                layer.promo_img = engine.UIAvatar.create("res/GUI/image/icon_promo.png","res/GUI/image/icon_promo.png");
                layer.node.addChild(layer.promo_img);
            }


            this.layers.push(layer);
        }

    },
    setInfo: function (infos) {
        for (var i = 0; i < GAME_IN_ROW; i++) {
            this.layers[i].setVisible(false);
        }
        for (var i = 0; i < infos.length; i++) {
            var infoReal = isNaN(infos[i])?infos[i]:DataManager.getInstance().mapDatas[infos[i]];

            this.layers[i].setVisible(true);
            this.layers[i].node.setVisible(false);
            this.layers[i].name.setString(infoReal.name);
            this.setRateFor1Layer(this.layers[i],infoReal.rate);
            if(infoReal.id == 0)        // promo
            {
                if(hideIcon )
                    this.layers[i].sprite.setTexture(cc.textureCache.addImage("res/game.png"));
                else
                {
                    this.layers[i].sprite.setVisible(false);
                    this.layers[i].node.setVisible(true);
                    this.layers[i].name.setString(infoReal.name);
                    this.setRateFor1Layer(this.layers[i],infoReal.rate);
                    this.layers[i].promo_img.asyncExecuteWithUrl(infoReal.package,infoReal.link_img);
                }
                continue;
            }
            this.layers[i].sprite.setVisible(true);
            if(hideIcon )
                this.layers[i].sprite.setTexture(cc.textureCache.addImage("res/game.png"));
            else
                this.layers[i].sprite.setTexture(cc.textureCache.addImage("res/data/" + infoReal.id + "/" + infoReal.id + "-0.png"));

        }

        this.infos = infos;
    },
    setRateFor1Layer: function(layer,rate)
    {
        if(rate == 0)
        {
            for(var i=0;i<layer.starss.length;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_empty.png"));
            }
        }
        else if(rate >= layer.starss.length)
        {
            for(var i=0;i<layer.starss.length;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_full.png"));
            }
        }
        else
        {
            var rateLamtron = Math.floor(rate);
            for(var i=0;i<rateLamtron;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_full.png"));
            }
            for(var i=rateLamtron;i<layer.starss.length;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_empty.png"));
            }
            if(rateLamtron < rate)
            {
                layer.starss[rateLamtron].setTexture(cc.textureCache.addImage("res/GUI/store/star_half.png"));
            }

        }
    }
});

var ListRomLayer = BaseLayer.extend({
    ctor: function (tableSize) {
        this._super();
        this.datas = [];

        this.tableView = cc.TableView.create(this, tableSize);
        this.tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.tableView.setDelegate(this);
        this.tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        this.tableView.reloadData();

        this.addChild(this.tableView);

        this.infoROM = null;

    },
    loadData: function (data) {
        this.datas = [];

        if(data.length == 0)
        {
            this.tableView.reloadData();
            return;
        }

        var count = Math.floor(data.length / GAME_IN_ROW);
        if (count <= 0) {
            this.datas.push(data);
        }
        else {
            for (var i = 0; i < count; i++) {
                var info = [];
                for (var j = 0; j < GAME_IN_ROW; j++) {
                    info.push(data[i * GAME_IN_ROW + j]);
                }
                this.datas.push(info);
            }
            if (data.length - count * GAME_IN_ROW > 0) {
                var info = [];
                for (var i = count * GAME_IN_ROW; i < data.length; i++) {
                    info.push(data[i]);
                }
                this.datas.push(info);
            }
        }
        this.tableView.reloadData();


    },
    tableCellTouched: function (table, cell) {
        if (!this.isVisible() || !table.isVisible())
            return;

        var releasePoint = cell.convertToNodeSpaceAR(cell.getTouchend());
        for (var i = GAME_IN_ROW-1; i >= 0; i--) {
            if (cell.layers[i].isVisible() && releasePoint.x >= (cell.layers[i].getPositionX())) {
                if (i <= 1 && releasePoint.x > (cell.layers[i].getPositionX() + cell.layers[i].sprite.getContentSize().width))
                    break;
                var infoReal = isNaN(cell.infos[i])?cell.infos[i]:DataManager.getInstance().mapDatas[cell.infos[i]];
                if(infoReal.id == 0)
                {
                    var exist = engine.PlatformWrapper.isPackageExist(infoReal.package);
                    cc.log("exsit :" + exist);
                    if(exist)
                    {
                        engine.PlatformWrapper.openApp(infoReal.package);
                    }
                    else
                    {
                        var promo = new PromoDialog();
                        promo.setInfo(infoReal);
                        this.getParent().addChild(promo,10);
                    }


                    return;
                }

                this.infoROM.setInfo(infoReal);
                break;
            }
        }
        this.infoROM.stopAllActions();
        this.stopAllActions();
        this.infoROM.runAction(cc.sequence(cc.show(), cc.moveTo(.2, cc.p(0, 0))));
        this.runAction(cc.sequence(cc.moveTo(.2, cc.p(-cc.winSize.width, 0)), cc.hide()));

    },

    tableCellSizeForIndex: function (table, idx) {

        return cc.size(175, 250);
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();
        if (!cell) {
            cell = new NESCell();
        }
        cell.setInfo(this.datas[idx]);
        return cell;
    },

    numberOfCellsInTableView: function (table) {
        //cc.log(this.datas.length)
        return this.datas.length;
    },
    scrollViewDidScroll: function (view) {
    },
    scrollViewDidZoom: function (view) {
    }
})


var SNESCell = cc.TableViewCell.extend({
    ctor: function () {
        this._super();

        this.layers = [];
        var poss = [cc.p(10, 0), cc.p(232, 0), cc.p(455, 0), cc.p(700, 0), cc.p(920, 0)];

        for (var i = 0; i < GAME_IN_ROW; i++) {
            var layer = new BaseLayer();
            layer.initGUICCB("res/GUI/", "res/GUI/CCBI/RomCell.ccbi");
            this.addChild(layer);
            layer.setPosition(poss[i]);
            layer.starss= [];
            layer.index = i;
            for(var j=1;j<=8;j++)
            {
                layer.starss.push(layer.stars.getChildByTag(j));
            }
            if(cc.isNative)
            {
                layer.promo_img = engine.UIAvatar.create("res/GUI/image/icon_promo.png","res/GUI/image/icon_promo.png");
                layer.node.addChild(layer.promo_img);
                layer.promo_img.setScaleX(1.2);
                layer.downloadFunc = function(url,jData)
                {
                    var objDown = JSON.parse(jData);
                    if(objDown.downloaded == objDown.totalSize)
                    {
                        this.status.setString("download finished");
                    }
                    else{
                        this.status.setString("downloading ("+ StringUtility.size2str(objDown.downloaded) +"/" + StringUtility.size2str(objDown.totalSize)+")");
                    }
                }.bind(layer);
                layer.objHandler = null;
            }


            this.layers.push(layer);
        }

    },
    setInfo: function (infos) {
        for (var i = 0; i < GAME_IN_ROW; i++) {
            this.layers[i].setVisible(false);
        }
        for (var i = 0; i < infos.length; i++) {
            var infoReal = isNaN(infos[i])?infos[i]:DataManager.getInstance().mapDatas[infos[i]];


            this.layers[i].setVisible(true);
            this.layers[i].node.setVisible(false);
            this.layers[i].name.setString(infoReal.name);
            this.setRateFor1Layer(this.layers[i],infoReal.rate);


            if(infoReal.id == 0)        // promo
            {
                var exist = engine.PlatformWrapper.isPackageExist(infoReal.package);

                this.layers[i].status.setString(exist?"":"(need download)");
                this.layers[i].promo_img.setTexture(cc.textureCache.addImage("res/game.png"));
                if(!hideIcon)
                {
                    this.layers[i].sprite.setVisible(false);
                    this.layers[i].node.setVisible(true);
                    this.layers[i].name.setString(infoReal.name);
                    this.setRateFor1Layer(this.layers[i],infoReal.rate);
                    this.layers[i].promo_img.asyncExecuteWithUrl(infoReal.name,infoReal.link_img);
                }
                continue;
            }

            this.layers[i].sprite.setVisible(true);
            if(cc.isNative)
                this.layers[i].promo_img.setTexture(cc.textureCache.addImage("res/game.png"));
                this.layers[i].promo_img.asyncExecuteWithUrl(infoReal.id,infoReal.urlImage);
                // snes
                this.layers[i].sprite.setVisible(false);
                this.layers[i].node.setVisible(true);

                if(!hideIcon)
                {


                }

                if(this.layers[i].objHandler != null)
                {
                    this.layers[i].objHandler.callFunc = null;
                    this.layers[i].objHandler = null;
                }

                if(downloadMgr.isFileExist(JSON.stringify(infoReal)))
                {
                    this.layers[i].status.setString("");
                }
                else
                {
                    if(downloadMgr.isDownloadThreadExist(infoReal.url))
                    {
                        var objDown = JSON.parse(downloadMgr.getDownloadInfo(infoReal.url));
                        this.layers[i].status.setString("downloading " + StringUtility.size2str(objDown.downloaded) +"/" + StringUtility.size2str(objDown.totalSize) );
                        this.layers[i].objHandler =  getCallbackObject(infoReal.url);
                        if(this.layers[i].objHandler)
                            this.layers[i].objHandler.callFunc = this.layers[i].downloadFunc;
                    }
                    else
                    {
                        this.layers[i].status.setString("(need_download)");
                    }
                }

        }

        this.infos = infos;
    },
    setRateFor1Layer: function(layer,rate)
    {
        if(rate == 0)
        {
            for(var i=0;i<layer.starss.length;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_empty.png"));
            }
        }
        else if(rate >= layer.starss.length)
        {
            for(var i=0;i<layer.starss.length;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_full.png"));
            }
        }
        else
        {
            var rateLamtron = Math.floor(rate);
            for(var i=0;i<rateLamtron;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_full.png"));
            }
            for(var i=rateLamtron;i<layer.starss.length;i++)
            {
                layer.starss[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_empty.png"));
            }
            if(rateLamtron < rate)
            {
                layer.starss[rateLamtron].setTexture(cc.textureCache.addImage("res/GUI/store/star_half.png"));
            }

        }
    }
});

var ListRomSNESLayer = BaseLayer.extend({
    ctor: function (tableSize) {
        this._super();
        this.datas = [];

        this.tableView = cc.TableView.create(this, tableSize);
        this.tableView.setDirection(cc.SCROLLVIEW_DIRECTION_VERTICAL);
        this.tableView.setDelegate(this);
        this.tableView.setVerticalFillOrder(cc.TABLEVIEW_FILL_TOPDOWN);
        this.tableView.reloadData();

        this.addChild(this.tableView);

        this.infoROM = null;

    },
    loadData: function (data) {
        this.datas = [];

        if(data.length == 0)
        {
            this.tableView.reloadData();
            return;
        }

        var count = Math.floor(data.length / GAME_IN_ROW);
        if (count <= 0) {
            this.datas.push(data);
        }
        else {
            for (var i = 0; i < count; i++) {
                var info = [];
                for (var j = 0; j < GAME_IN_ROW; j++) {
                    info.push(data[i * GAME_IN_ROW + j]);
                }
                this.datas.push(info);
            }
            if (data.length - count * GAME_IN_ROW > 0) {
                var info = [];
                for (var i = count * GAME_IN_ROW; i < data.length; i++) {
                    info.push(data[i]);
                }
                this.datas.push(info);
            }
        }
        this.tableView.reloadData();


    },
    tableCellTouched: function (table, cell) {
        if (!this.isVisible() || !table.isVisible())
            return;

        var releasePoint = cell.convertToNodeSpaceAR(cell.getTouchend());
        for (var i = GAME_IN_ROW-1; i >= 0; i--) {
            if (cell.layers[i].isVisible() && releasePoint.x >= (cell.layers[i].getPositionX())) {
                if (i <= 1 && releasePoint.x > (cell.layers[i].getPositionX() + cell.layers[i].sprite.getContentSize().width))
                    break;
                var infoReal = isNaN(cell.infos[i])?cell.infos[i]:DataManager.getInstance().mapDatas[cell.infos[i]];

                if(infoReal.id == 0)
                {
                    var exist = engine.PlatformWrapper.isPackageExist(infoReal.package);
                    if(exist)
                    {
                        engine.PlatformWrapper.openApp(infoReal.package);
                    }
                    else
                    {
                        var promo = new PromoDialog();
                        promo.setInfo(infoReal);
                        this.getParent().addChild(promo,10);
                    }


                    return;
                }


                var gameInfoData = JSON.stringify(infoReal);
                if(!downloadMgr.isFileExist(gameInfoData))
                {
                    if(downloadMgr.isDownloadThreadExist(infoReal.url))
                    {
                        cc.log("dang down roi nhe")
                    }
                    else
                    {
                        if(downloadMgr.addDownloadTask(gameInfoData))
                        {
                            cell.layers[i].objHandler = handlerAdd(infoReal.url,cell.layers[i].downloadFunc);
                            cell.layers[i].status.setString("(donwloading)");
                        }
                        else
                        {

                        }
                    }
                }
                else
                {
                    this.retain();
                    this.removeFromParent();

                    DataManager.getInstance().addRomRecent(infoReal.id);

                    var gamescene = new GameScene();
                    gamescene.loadGame(infoReal);
                    gamescene = cc.TransitionSlideInR.create(.25,makeScene(gamescene));
                    sceneMgr.replaceWithScene(gamescene,gamescene);

                    tangCount();
                }

                break;
            }
        }
        //this.infoROM.stopAllActions();
        //this.stopAllActions();
        //this.infoROM.runAction(cc.sequence(cc.show(), cc.moveTo(.2, cc.p(0, 0))));
        //this.runAction(cc.sequence(cc.moveTo(.2, cc.p(-cc.winSize.width, 0)), cc.hide()));

    },

    tableCellSizeForIndex: function (table, idx) {

        return cc.size(175, 250);
    },

    tableCellAtIndex: function (table, idx) {
        var cell = table.dequeueCell();
        if (!cell) {
            cell = new SNESCell();
        }
        cell.setInfo(this.datas[idx]);
        return cell;
    },

    numberOfCellsInTableView: function (table) {
        //cc.log(this.datas.length)
        return this.datas.length;
    },
    scrollViewDidScroll: function (view) {
    },
    scrollViewDidZoom: function (view) {
    }
})


var InfoROMLayer = BaseLayer.extend({
    ctor: function () {
        this._super();

        var gui_path = "res/GUI/CCBI/InfoNESLayer.ccbi";
        if(gameData.screenType == SCREEN_PORTRAIT)
            gui_path = "res/GUI/CCBI/InfoNESLayerP.ccbi";

        this.initGUICCB("res/GUI/", gui_path);

        var container = this.scrollView.getContainer();

        this.name = container.getChildByTag(10);
        this.type = container.getChildByTag(15);
        this.icon = container.getChildByTag(11);
        this.intro = container.getChildByTag(16);

        this.stars = [];
        for (var i = 1; i <= 8; i++) {
            this.stars.push(container.getChildByTag(14).getChildByTag(i));
        }

        this.screenShots = [];

        this.screenShots.push(container.getChildByTag(17));
        this.screenShots.push(container.getChildByTag(18));
        this.screenShots.push(container.getChildByTag(19));
        this.screenShots.push(container.getChildByTag(20));

        this.tem = container.getChildByTag(12);
        this.price = container.getChildByTag(13);

        this.addFavorite = container.getChildByTag(24);

        this.customizeButtonInScrollView(this.scrollView, InfoROMLayer.BTN_BACK);
        this.customizeButtonInScrollView(this.scrollView, InfoROMLayer.BTN_PLAY);
        this.customizeButtonInScrollView(this.scrollView, InfoROMLayer.BTN_BUY);
        this.btnFavorite = this.customizeButtonInScrollView(this.scrollView, InfoROMLayer.BTN_FAVORITE);



        this.favorite = false;

        this.listROM = null;
    },
    setInfo: function (info) {
        this.name.setString(info.name);
        this.type.setString(info.type);

        this.intro.setString(info.intro);
        this.intro.setDimensions(cc.size(cc.winSize.width - 20,350));
        if(hideIcon)
            this.icon.setTexture(cc.textureCache.addImage("res/game.png"));
        else
            this.icon.setTexture(cc.textureCache.addImage("res/data/" + info.id + "/" + info.id + "-0.png"));


        for (var i = 0; i < this.screenShots.length; i++) {
            var imageCheck = "res/data/" + info.id + "/" + info.id + "-" + (i + 1) + ".png";
            if (cc.isNative) {
                var exist = cc.FileUtils.getInstance().isFileExist(cc.FileUtils.getInstance().fullPathForFilename(imageCheck));
                if (exist) {
                    this.screenShots[i].setVisible(!hideIcon);
                    this.screenShots[i].setTexture(cc.textureCache.addImage(cc.FileUtils.getInstance().fullPathForFilename(imageCheck)));
                }
                else
                    this.screenShots[i].setVisible(false);


            }
            else {
                if (i == 0 || i == 1) {
                    this.screenShots[i].setVisible(true);
                    this.screenShots[i].setTexture(cc.textureCache.addImage(cc.FileUtils.getInstance().fullPathForFilename(imageCheck)));

                }
                else
                    this.screenShots[i].setVisible(false);

            }
        }

        if (findID(info.id, DataManager.getInstance().romFavorites)) {
            this.favorite = true;
            this.btnFavorite.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/yeuthich_select.png", cc.rect(0, 0, 261, 264)), cc.CONTROL_STATE_NORMAL);
            this.addFavorite.setString("Added to Favorites");
        }
        else {
            this.favorite = false;
            this.btnFavorite.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/yeuthich_no_select.png", cc.rect(0, 0, 261, 264)), cc.CONTROL_STATE_NORMAL);
            this.addFavorite.setString("");
        }
        this.info = info;
        this.setRate(info.rate);
    },
    setViewSize: function (size) {
        this.scrollView.setViewSize(size);
        this.scrollView.setContentOffset(cc.p(0, size.height - this.scrollView.getContainer().getContentSize().height));
    },
    setPrice: function (price) {

    },
    setRate: function(rate){
      if(rate == 0)
      {
          for(var i=0;i<this.stars.length;i++)
          {
              this.stars[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_empty.png"));
          }
      }
        else if(rate >= this.stars.length)
      {
          for(var i=0;i<this.stars.length;i++)
          {
              this.stars[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_full.png"));
          }
      }
        else
      {
          var rateLamtron = Math.floor(rate);
          for(var i=0;i<rateLamtron;i++)
          {
              this.stars[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_full.png"));
          }
          for(var i=rateLamtron;i<this.stars.length;i++)
          {
              this.stars[i].setTexture(cc.textureCache.addImage("res/GUI/store/star_empty.png"));
          }
          if(rateLamtron < rate)
          {
              this.stars[rateLamtron].setTexture(cc.textureCache.addImage("res/GUI/store/star_half.png"));
          }

      }
    },
    onButtonReleased: function (btn, id) {
        switch (id) {
            case InfoROMLayer.BTN_BACK:
            {
                this.listROM.runAction(cc.sequence(cc.show(), cc.moveTo(.2, cc.p(0, 0))));
                this.runAction(cc.sequence(cc.moveTo(.2, cc.p(cc.winSize.width, 0)), cc.hide()));
                break;
            }
            case InfoROMLayer.BTN_BUY:
            {
                break;
            }
            case InfoROMLayer.BTN_FAVORITE:
            {
                this.addFavorite.stopAllActions();
                this.addFavorite.setVisible(false);
                this.addFavorite.setOpacity(0);
                if (!this.favorite) {
                    DataManager.getInstance().addRomFavorite(this.info.id);
                    this.favorite = true;
                    this.btnFavorite.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/yeuthich_select.png", cc.rect(0, 0, 261, 264)), cc.CONTROL_STATE_NORMAL);
                    this.addFavorite.setString("Added to Favorites");
                }
                else {
                    this.favorite = false;
                    this.btnFavorite.setBackgroundSpriteFrameForState(cc.SpriteFrame.create("res/GUI/store/yeuthich_no_select.png", cc.rect(0, 0, 261, 264)), cc.CONTROL_STATE_NORMAL);
                    this.addFavorite.setString("Removed from Favorites");
                    DataManager.getInstance().removeRomFavorite(this.info.id);

                }
                this.addFavorite.runAction(cc.sequence(cc.show(),cc.fadeIn(.5),cc.delayTime(1),cc.fadeOut(.5),cc.hide()));
                break;
            }
            case InfoROMLayer.BTN_PLAY:
            {

                DataManager.getInstance().addRomRecent(this.info.id);
                listROM.retain();
                listROM.removeFromParent();
                var gamescene = new GameScene();
                gamescene.loadGame(this.info);
                gamescene = cc.TransitionSlideInR.create(.25,makeScene(gamescene));
                sceneMgr.replaceWithScene(gamescene,gamescene);

                tangCount();

                break;
            }
        }
    }

})

InfoROMLayer.BTN_BACK = 4;
InfoROMLayer.BTN_PLAY = 3;
InfoROMLayer.BTN_BUY = 5;
InfoROMLayer.BTN_FAVORITE = 23;


var PromoDialog = BaseLayer.extend({
    ctor: function (lis) {
        this._super();
        this.initGUICCB("res/GUI/", "res/GUI/CCBI/PromoLayer.ccbi");

    },
    customizeGUI: function()
    {
        this.lb_title = this.title;
        this.lb_message = this.desc;

        this.addTouchEventForButton(this.btnInstall,0).setTouchPriority(-2);
        this.addTouchEventForButton(this.btnLater,1).setTouchPriority(-2);

        this.node.img = engine.UIAvatar.create("res/GUI/image/icon_promo.png","res/GUI/image/icon_promo.png");
        this.node.addChild(this.node.img);

    },
    setInfo: function(info)
    {
        this.info = info;
        this.title.setString(info.name);
        this.desc.setString(info.intro);
        this.node.img.asyncExecuteWithUrl(info.package,info.link_img);
    },

    onEnter: function () {
        this._super();
        this.fogLayer.setVisible(true);
        this.fogLayer.stopAllActions();
        this.fogLayer.setOpacity(0);
        this.fogLayer.runAction(cc.FadeTo.create(.275, 175))

        this.setFog(true);


    },
    onExit: function()
    {
        cc.unregisterTouchDelegate(this);
        this._super();
    },
    onButtonReleased: function(btn,id)
    {
        if(!btn.isVisible())
            return;
        switch (id)
        {
            case 0:
            {
                engine.AdmobHelper.openURL(this.info.link);;
                break;
            }
            case 1:
            {
                this.removeFromParent();
                break;
            }
        }
    }
})

var MenuLayer = BaseLayer.extend({
    ctor: function(home)
    {
        this._super();
        this.homeLayer = home;
        this.initGUICCB("res/GUI/","res/GUI/CCBI/MenuLayer.ccbi");
    },
    customizeGUI: function()
    {
        this.l_color.setVisible(false);
        this.addTouchEventForButton(this.btnAddGame,0).setTouchPriority(-2);
        this.addTouchEventForButton(this.btnRate,1).setTouchPriority(-2);

        if(hideGame)
        {
            this.lbAddGame.setString("Add games");
        }
        else
        {
            this.lbAddGame.setString("Device roms");
        }

    },

    onButtonTouched: function(btn,id)
    {
        switch (id)
        {
            case 0:
            {
                if(gameData.fake)
                {
                    engine.EMUWrapper.chooseFile();
                    handlerAdd("chooseFile",function(id,jData){
                        var gamescene = new GameScene();
                        sceneMgr.replaceWithScene(makeScene(gamescene));
                    });
                }
                else
                {
                    if(hideGame)
                    {
                        sys.localStorage.setItem("hideGame","1");
                        currentTab = -1;
                        this.homeLayer.onButtonReleased(this.homeLayer.btnList,this.homeLayer.btnList.getTag(),true);
                    }
                    else
                    {
                        engine.EMUWrapper.chooseFile();
                        handlerAdd("chooseFile",function(id,jData){
                            var gamescene = new GameScene();
                            sceneMgr.replaceWithScene(makeScene(gamescene));
                        });
                    }

                }
                this.layout.runAction(cc.moveTo(.2,cc.p(-this.layer_bg.getContentSize().width,0)));
                this.runAction(cc.sequence(cc.delayTime(.2),cc.removeSelf()));

                break;
            }
            case 1:
            {
                if (cc.isNative)
                    engine.AdmobHelper.openURL(gameData.urlRate || ("market://details?id="+cc.isNative?engine.PlatformWrapper.getPackageName():""));
                break;
            }
        }
    },
    onEnter: function()
    {
        this._super();
        this.layout.setPositionX(-this.layer_bg.getContentSize().width);
        this.layout.runAction(cc.moveTo(.2,cc.p(0,0)));
        this.setFog(true);
    },
    quit: function()
    {
        this.layout.runAction(cc.moveTo(.2,cc.p(-this.layer_bg.getContentSize().width,0)));
        this.runAction(cc.sequence(cc.delayTime(.2),cc.removeSelf()));
    },
    onTouchBegan: function (touch, event) {
        if (!this.isVisible())
            return false;
        if (this.fog)
        {
            if(touch.getLocation().x > this.layer_bg.getContentSize().width)
            {
                this.quit();
            }

            return true;
        }
    }
})

var UpdateDialog = BaseLayer.extend({
    ctor: function (lis) {
        this._super();
        this.initGUICCB("res/GUI/", "res/GUI/CCBI/PromoLayer.ccbi");

    },
    customizeGUI: function()
    {
        this.lb_title = this.title;
        this.lb_message = this.desc;

        this.addTouchEventForButton(this.btnInstall,0).setTouchPriority(-2);
        this.addTouchEventForButton(this.btnLater,1).setTouchPriority(-2);

        this.node.img = engine.UIAvatar.create("res/game.png","res/game.png");
        this.node.addChild(this.node.img);
        this.setInfo(null);

    },
    setInfo: function(info)
    {
        //this.info = info;
        this.title.setString("Version Updater");
        this.desc.setString("-Recommend update new version for SNES.\n-Fix crash and multiplayer.\n-Optimize performance for feeling.");
        //this.node.img.asyncExecuteWithUrl(info.package,info.link_img);

        //this.btnInstall.setTitleForState("Update Now",cc.CONTROL_STATE_NORMAL);
        this.btnLater.setTitleForState("Update Later",cc.CONTROL_STATE_NORMAL);
    },

    onEnter: function () {
        this._super();
        this.fogLayer.setVisible(true);
        this.fogLayer.stopAllActions();
        this.fogLayer.setOpacity(0);
        this.fogLayer.runAction(cc.FadeTo.create(.275, 175))

        this.setFog(true);


    },
    onExit: function()
    {
        cc.unregisterTouchDelegate(this);
        this._super();
    },
    onButtonReleased: function(btn,id)
    {
        if(!btn.isVisible())
            return;
        switch (id)
        {
            case 0:
            {
                engine.AdmobHelper.openURL("market://details?id=emu.gba.arcade.nes.snes.neww.one");
                break;
            }
            case 1:
            {
                this.removeFromParent();
                break;
            }
        }
    }
})

